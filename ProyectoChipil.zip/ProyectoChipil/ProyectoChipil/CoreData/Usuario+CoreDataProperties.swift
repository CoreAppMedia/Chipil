//
//  Usuario+CoreDataProperties.swift
//  ProyectoChipil
//
//  Created by mac20@ioslabacatlan.appleid.com on 22/10/23.
//
//

